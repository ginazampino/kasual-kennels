How to use:

1) This converter takes mass images located in the Graphics folder, 
converts them to .PNG format whilst seting the image's background to transparent.

2) Images must directly be put into the Graphics folder and not in sub-folders.

3) All converted images will be put into the Converted folder.

4) Source IS included if somthing breaks or this is not what you idealy want.

For more on support with your games development, visit www.AscensionGameDev.com

-Kibbelz