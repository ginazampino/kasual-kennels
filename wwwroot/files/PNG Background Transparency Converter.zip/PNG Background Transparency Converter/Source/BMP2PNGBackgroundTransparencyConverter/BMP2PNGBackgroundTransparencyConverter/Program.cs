﻿/*
    The MIT License (MIT)

    Copyright (c) 2015 JC Snider, Joe Bridges
  
    Website: http://ascensiongamedev.com
    Contact Email: admin@ascensiongamedev.com

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.IO;

namespace BMP2PNGBackgroundTransparencyConverter
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Bitmap bmp = null;
                string[] files = Directory.GetFiles("Graphics\\");

                Console.WriteLine(".BMP to .PNG Converter!");
                Console.WriteLine("Whilst making the image background transparent!");
                Console.WriteLine("Tool provided by Ascension Game Dev, at www.AscensionGameDev.com");
                Console.WriteLine("Tool written by Kibbelz");
                Console.WriteLine("Press any key to continue... \n");
                Console.ReadLine();

                foreach (string filename in files)
                {
                    bmp = (Bitmap)Image.FromFile(filename);
                    bmp = ChangeColor(bmp);
                    string[] spliter = filename.Split('\\');
                    string[] extension = spliter[1].Split('.');

                    bmp.Save("Converted\\" + extension[0] + ".png");
                    Console.WriteLine(spliter[1] + " Converted.");
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

            Console.WriteLine("Conversion complete");
            Console.WriteLine("Press any key to continue...");
        }

        public static Bitmap ChangeColor(Bitmap scrBitmap)
        {

            Color newColor = Color.Transparent;
            Color oldBackground = scrBitmap.GetPixel(0, 0); //Use top left pixel as reference.
            Color actualColor;

            //make an empty bitmap the same size as scrBitmap
            Bitmap newBitmap = new Bitmap(scrBitmap.Width, scrBitmap.Height);
            for (int i = 0; i < scrBitmap.Width; i++)
            {
                for (int j = 0; j < scrBitmap.Height; j++)
                {
                    //get the pixel from the scrBitmap image
                    actualColor = scrBitmap.GetPixel(i, j);

                    if (actualColor == oldBackground)
                        newBitmap.SetPixel(i, j, newColor);
                    else
                        newBitmap.SetPixel(i, j, actualColor);
                }
            }
            return newBitmap;
        }
    }
}
